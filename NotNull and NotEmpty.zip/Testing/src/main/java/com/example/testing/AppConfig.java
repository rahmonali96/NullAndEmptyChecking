package com.example.testing;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

}
